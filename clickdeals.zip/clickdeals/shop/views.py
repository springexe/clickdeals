from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

from .models import Product
from math import ceil
def index(request):
    products = Product.objects.all()
    print(products)
    n = len(products)
    nSlides = n //4 + ceil((n/4)-(n//4))
    params = {'no_of_slides':nSlides ,'range':range(1,nSlides),'product':products}
    return render(request,'shop/index.html',params)

def about(request):
    return render(request,'shop/about.html')

def contact(request):
    return HttpResponse("This is shop contact")

def tracker(request):
    return HttpResponse("This is shop tracker")

def search(request):
    return HttpResponse("This is shop search")

def productView(request):
    return HttpResponse("This is shop product view")

def checkout(request):
    return HttpResponse("This is shop checkout")
